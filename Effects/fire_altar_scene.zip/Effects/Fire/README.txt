# Fire Altar FX

Dépose le dossier `Effects/Fire` dans ton projet Godot.

## Fichiers
- `fire_altar_fx.tscn` : scène prête à tester
- `fire_altar_fx.gd` : start_fire() / stop_fire()
- `fire_altar.gdshader` : shader principal du feu
- `white_soft.png` : texture blanche soft utilisée par le sprite, les braises et la lumière

## Test rapide
1. Ouvre `fire_altar_fx.tscn`
2. Lance la scène
3. Tu peux appeler :
   - `start_fire()`
   - `stop_fire()`

## Réglages rapides
Dans `FireSprite > Material` :
- speed
- wobble_strength
- flame_width
- flame_height

Dans `Embers` :
- amount
- lifetime
- initial_velocity
