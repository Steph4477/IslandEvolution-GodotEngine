extends Node2D

@onready var fire_sprite = $FireSprite
@onready var embers = $Embers
@onready var light = $PointLight2D

func start_fire():
	fire_sprite.show()
	embers.emitting = true
	light.enabled = true

func stop_fire():
	fire_sprite.hide()
	embers.emitting = false
	light.enabled = false
